import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class PhysicalAssetsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_physical_assets)

        // Set click listeners for asset management buttons
        val realEstateButton: Button = findViewById(R.id.realEstateButton)
        val goldButton: Button = findViewById(R.id.goldButton)
        val bondsButton: Button = findViewById(R.id.bondsButton)
        val goBackButton: Button = findViewById(R.id.goBackButton)

        realEstateButton.setOnClickListener {
            onRealEstateClick()
        }

        goldButton.setOnClickListener {
            onGoldClick()
        }

        bondsButton.setOnClickListener {
            onBondsClick()
        }

        goBackButton.setOnClickListener {
            goBack()
        }
    }

    // Navigate to the Real Estate management page
    fun onRealEstateClick() {
        val intent = Intent(this, RealEstateActivity::class.java)
        startActivity(intent)
    }

    // Navigate to the Gold management page
    fun onGoldClick() {
        val intent = Intent(this, GoldActivity::class.java)
        startActivity(intent)
    }

    // Navigate to the Bonds management page
    fun onBondsClick() {
        val intent = Intent(this, BondsActivity::class.java)
        startActivity(intent)
    }

    // Go back to the previous activity
    fun goBack() {
        finish() // Close the current activity
    }
}
