import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class DigitalAssetsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DigitalAssetsApp()
        }
    }
}

@Composable
fun DigitalAssetsApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "digital_assets") {
        composable("digital_assets") { DigitalAssetsScreen(navController) }
        composable("investments") { InvestmentsScreen() }
        composable("banks") { BanksScreen() }
        composable("insurance") { InsuranceScreen() }
    }
}

@Composable
fun DigitalAssetsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Digital Assets - WorthUnzip") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Manage Your Digital Assets",
                style = MaterialTheme.typography.h4,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 16.dp)
            )
            Text(
                text = "Select the asset type you want to manage:",
                style = MaterialTheme.typography.body1,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Button(
                onClick = { navController.navigate("investments") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text("Investments")
            }
            Button(
                onClick = { navController.navigate("banks") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text("Banks")
            }
            Button(
                onClick = { navController.navigate("insurance") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Insurance")
            }

            Spacer(modifier = Modifier.height(32.dp))

            ClickableText(
                text = AnnotatedString("← Go Back"),
                onClick = { navController.popBackStack() },
                style = MaterialTheme.typography.body1.copy(fontSize = 18.sp)
            )
        }
    }
}

@Composable
fun InvestmentsScreen() {
    // Placeholder for Investments Screen
    ScreenPlaceholder("Investments")
}

@Composable
fun BanksScreen() {
    // Placeholder for Banks Screen
    ScreenPlaceholder("Banks")
}

@Composable
fun InsuranceScreen() {
    // Placeholder for Insurance Screen
    ScreenPlaceholder("Insurance")
}

@Composable
fun ScreenPlaceholder(screenName: String) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("$screenName - WorthUnzip") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$screenName Screen Placeholder",
                style = MaterialTheme.typography.h5,
                textAlign = TextAlign.Center
            )
        }
    }
}
