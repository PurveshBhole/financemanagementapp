import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class InvestmentsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InvestmentsApp()
        }
    }
}

@Composable
fun InvestmentsApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "investments") {
        composable("investments") { InvestmentsScreen(navController) }
        composable("real_estate") { RealEstateScreen() }
        composable("gold") { GoldScreen() }
        composable("bonds") { BondsScreen() }
    }
}

@Composable
fun InvestmentsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Investments - WorthUnzip") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                contentDescription = "WorthUnzip Logo",
                modifier = Modifier.size(100.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Investments",
                style = MaterialTheme.typography.h4
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { navController.navigate("real_estate") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text("Real Estate")
            }

            Button(
                onClick = { navController.navigate("gold") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text("Gold")
            }

            Button(
                onClick = { navController.navigate("bonds") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Bonds")
            }
        }
    }
}

@Composable
fun RealEstateScreen() {
    CommonScreen("Real Estate")
}

@Composable
fun GoldScreen() {
    CommonScreen("Gold")
}

@Composable
fun BondsScreen() {
    CommonScreen("Bonds")
}

@Composable
fun CommonScreen(title: String) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("$title Details (Placeholder)", style = MaterialTheme.typography.h5)
        }
    }
}
