import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class DashboardActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            UserDashboardApp()
        }
    }
}

@Composable
fun UserDashboardApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") { DashboardScreen(navController) }
        composable("physical_assets") { PhysicalAssetsScreen() }
        composable("digital_assets") { DigitalAssetsScreen() }
    }
}

@Composable
fun DashboardScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WorthUnzip Dashboard") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Welcome to Your Dashboard",
                style = MaterialTheme.typography.h4,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Navigation Buttons
            Button(
                onClick = { navController.navigate("physical_assets") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Text("Physical Assets")
            }
            Button(
                onClick = { navController.navigate("digital_assets") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Digital Assets")
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { downloadAllInvestmentDetails() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Green),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Download All Investment Details", color = Color.White)
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Log Out",
                color = MaterialTheme.colors.primary,
                modifier = Modifier.clickable { logout() },
                textAlign = TextAlign.Center,
                fontSize = 18.sp
            )
        }
    }
}

@Composable
fun PhysicalAssetsScreen() {
    // Placeholder for Physical Assets Screen
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "Physical Assets Screen")
    }
}

@Composable
fun DigitalAssetsScreen() {
    // Placeholder for Digital Assets Screen
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(text = "Digital Assets Screen")
    }
}

fun downloadAllInvestmentDetails() {
    // This function would handle the export logic.
    // Simulate download action using a Toast or any action
    println("Downloading all investment details...")
}

fun logout() {
    // Placeholder for logout action
    println("Logged out!")
}
