import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import com.example.worthunzip.ui.theme.WorthUnzipTheme

data class Investment(val name: String, val amount: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WorthUnzipTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
                    InvestmentManagerScreen()
                }
            }
        }
    }
}

@Composable
fun InvestmentManagerScreen() {
    var investmentType by remember { mutableStateOf("") }
    val investmentData = remember { mutableStateMapOf<String, MutableList<Investment>>() }
    var nameInput by remember { mutableStateOf(TextFieldValue("")) }
    var amountInput by remember { mutableStateOf(TextFieldValue("")) }
    var selectedInvestments by remember { mutableStateOf(emptyList<Investment>()) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Manage Your Investments", style = MaterialTheme.typography.h4)

        Spacer(modifier = Modifier.height(16.dp))

        DropdownMenu(
            label = "Select Investment Type",
            options = listOf("Stocks", "Mutual Funds", "Cryptocurrency", "Other"),
            selectedOption = investmentType,
            onOptionSelected = {
                investmentType = it
                selectedInvestments = investmentData[it] ?: emptyList()
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(selectedInvestments) { investment ->
                Card(modifier = Modifier.fillMaxWidth().padding(4.dp)) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Name: ${investment.name}")
                        Text("Amount: ${investment.amount}")
                    }
                }
            }
        }

        if (investmentType.isNotEmpty()) {
            TextField(
                value = nameInput,
                onValueChange = { nameInput = it },
                label = { Text("Investment Name") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            TextField(
                value = amountInput,
                onValueChange = { amountInput = it },
                label = { Text("Amount Invested (₹)") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
            Button(
                onClick = {
                    if (investmentType.isNotEmpty() && nameInput.text.isNotEmpty() && amountInput.text.isNotEmpty()) {
                        val investments = investmentData[investmentType] ?: mutableListOf()
                        investments.add(Investment(nameInput.text, amountInput.text))
                        investmentData[investmentType] = investments
                        nameInput = TextFieldValue("")
                        amountInput = TextFieldValue("")
                        selectedInvestments = investments
                        Toast.makeText(LocalContext.current, "Investment added!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            ) {
                Text("Add $investmentType Investment")
            }
        }
    }
}

@Composable
fun DropdownMenu(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { expanded = true }) {
            Text(selectedOption.ifEmpty { label })
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(onClick = {
                    onOptionSelected(option)
                    expanded = false
                }) {
                    Text(option)
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun InvestmentManagerScreenPreview() {
    WorthUnzipTheme {
        InvestmentManagerScreen()
    }
}
