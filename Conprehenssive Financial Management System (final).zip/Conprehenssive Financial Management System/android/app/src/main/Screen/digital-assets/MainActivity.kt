import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var bankFormContainer: LinearLayout
    private lateinit var bankDetailsDisplay: LinearLayout
    private lateinit var spinnerBank: Spinner
    private lateinit var etAccountNumber: EditText
    private lateinit var etIFSCCode: EditText
    private lateinit var etBalance: EditText
    private lateinit var bankListContainer: LinearLayout

    private val bankList = mutableListOf<BankDetails>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bankFormContainer = findViewById(R.id.bankFormContainer)
        bankDetailsDisplay = findViewById(R.id.bankDetailsDisplay)
        spinnerBank = findViewById(R.id.spinnerBank)
        etAccountNumber = findViewById(R.id.etAccountNumber)
        etIFSCCode = findViewById(R.id.etIFSCCode)
        etBalance = findViewById(R.id.etBalance)
        bankListContainer = findViewById(R.id.bankListContainer)

        val btnAddBank = findViewById<Button>(R.id.btnAddBank)
        val btnSaveBank = findViewById<Button>(R.id.btnSaveBank)
        val btnDownloadStatement = findViewById<Button>(R.id.btnDownloadStatement)

        // Populate spinner
        val bankNames = arrayOf("State Bank of India", "HDFC Bank", "ICICI Bank", "Axis Bank", "Kotak Mahindra Bank", "Punjab National Bank", "Bank of Baroda")
        spinnerBank.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bankNames)

        // Add Bank button click
        btnAddBank.setOnClickListener {
            bankFormContainer.visibility = View.VISIBLE
        }

        // Save Bank Details
        btnSaveBank.setOnClickListener {
            val bankName = spinnerBank.selectedItem.toString()
            val accountNumber = etAccountNumber.text.toString()
            val ifscCode = etIFSCCode.text.toString()
            val balance = etBalance.text.toString().toDouble()

            val bankDetails = BankDetails(bankName, accountNumber, ifscCode, balance)
            bankList.add(bankDetails)
            displayBankDetails()
            bankFormContainer.visibility = View.GONE
        }

        // Download Bank Statement
        btnDownloadStatement.setOnClickListener {
            downloadBankStatement()
        }
    }

    private fun displayBankDetails() {
        bankDetailsDisplay.visibility = View.VISIBLE
        bankListContainer.removeAllViews()

        bankList.forEachIndexed { index, bankDetails ->
            val textView = TextView(this).apply {
                text = "Bank ${index + 1}:\nBank: ${bankDetails.bank}\nAccount Number: ${bankDetails.accountNumber}\nIFSC Code: ${bankDetails.ifscCode}\nBalance: ₹${bankDetails.balance}"
                setPadding(16, 16, 16, 16)
            }
            bankListContainer.addView(textView)
        }
    }

    private fun downloadBankStatement() {
        if (bankList.isEmpty()) {
            Toast.makeText(this, "No bank details to download.", Toast.LENGTH_SHORT).show()
            return
        }

        val fileContent = StringBuilder("Bank Statement:\n\n")
        bankList.forEachIndexed { index, bankDetails ->
            fileContent.append("Bank ${index + 1}:\nBank: ${bankDetails.bank}\nAccount Number: ${bankDetails.accountNumber}\nIFSC Code: ${bankDetails.ifscCode}\nBalance: ₹${bankDetails.balance}\n\n")
        }

        val fileName = "BankStatement.txt"
        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName)
        FileOutputStream(file).use {
            it.write(fileContent.toString().toByteArray())
        }
        Toast.makeText(this, "Bank statement downloaded to ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    data class BankDetails(val bank: String, val accountNumber: String, val ifscCode: String, val balance: Double)
}
