package com.example.insuranceapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

data class Insurance(
    val type: String,
    val provider: String,
    val policyNumber: String,
    val premium: Double
)

class MainActivity : AppCompatActivity() {

    private lateinit var insuranceTypeSpinner: Spinner
    private lateinit var insuranceProviderEditText: EditText
    private lateinit var policyNumberEditText: EditText
    private lateinit var premiumAmountEditText: EditText
    private lateinit var addInsuranceButton: Button
    private lateinit var downloadInsuranceButton: Button
    private lateinit var insuranceRecyclerView: RecyclerView

    private val insuranceList = mutableListOf<Insurance>()
    private val adapter = InsuranceAdapter(insuranceList)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        insuranceTypeSpinner = findViewById(R.id.insuranceTypeSpinner)
        insuranceProviderEditText = findViewById(R.id.insuranceProviderEditText)
        policyNumberEditText = findViewById(R.id.policyNumberEditText)
        premiumAmountEditText = findViewById(R.id.premiumAmountEditText)
        addInsuranceButton = findViewById(R.id.addInsuranceButton)
        downloadInsuranceButton = findViewById(R.id.downloadInsuranceButton)
        insuranceRecyclerView = findViewById(R.id.insuranceRecyclerView)

        // RecyclerView setup
        insuranceRecyclerView.layoutManager = LinearLayoutManager(this)
        insuranceRecyclerView.adapter = adapter

        // Load saved insurance data
        loadInsuranceData()

        addInsuranceButton.setOnClickListener {
            addInsurance()
        }

        downloadInsuranceButton.setOnClickListener {
            downloadInsuranceDetails()
        }
    }

    private fun addInsurance() {
        val type = insuranceTypeSpinner.selectedItem.toString()
        val provider = insuranceProviderEditText.text.toString()
        val policyNumber = policyNumberEditText.text.toString()
        val premium = premiumAmountEditText.text.toString().toDoubleOrNull()

        if (provider.isBlank() || policyNumber.isBlank() || premium == null) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val insurance = Insurance(type, provider, policyNumber, premium)
        insuranceList.add(insurance)
        adapter.notifyDataSetChanged()
        saveInsuranceData()

        // Clear inputs
        insuranceProviderEditText.text.clear()
        policyNumberEditText.text.clear()
        premiumAmountEditText.text.clear()

        Toast.makeText(this, "Insurance added successfully!", Toast.LENGTH_SHORT).show()
    }

    private fun saveInsuranceData() {
        val sharedPreferences = getSharedPreferences("insurance_data", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val json = Gson().toJson(insuranceList)
        editor.putString("insurance_list", json)
        editor.apply()
    }

    private fun loadInsuranceData() {
        val sharedPreferences = getSharedPreferences("insurance_data", MODE_PRIVATE)
        val json = sharedPreferences.getString("insurance_list", null)
        val type = object : TypeToken<MutableList<Insurance>>() {}.type
        if (json != null) {
            insuranceList.addAll(Gson().fromJson(json, type))
        }
    }

    private fun downloadInsuranceDetails() {
        if (insuranceList.isEmpty()) {
            Toast.makeText(this, "No insurance data to download.", Toast.LENGTH_SHORT).show()
            return
        }

        val fileContent = buildString {
            insuranceList.forEachIndexed { index, insurance ->
                append("Insurance ${index + 1}:\n")
                append("Type: ${insurance.type}\n")
                append("Provider: ${insurance.provider}\n")
                append("Policy Number: ${insurance.policyNumber}\n")
                append("Premium Amount: $${insurance.premium}\n\n")
            }
        }

        val file = File(getExternalFilesDir(null), "InsuranceDetails.txt")
        file.writeText(fileContent)

        Toast.makeText(this, "File downloaded at: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }
}
