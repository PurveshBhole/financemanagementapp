import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.clickable
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class EnterMobileActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MobileNumberApp()
        }
    }
}

@Composable
fun MobileNumberApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "enter_mobile") {
        composable("enter_mobile") { EnterMobileScreen(navController) }
        composable("submission_result") { SubmissionResultScreen() }
    }
}

@Composable
fun EnterMobileScreen(navController: NavController) {
    var mobileNumber by remember { mutableStateOf("") }
    val isValidMobile = mobileNumber.length == 10 && mobileNumber.all { it.isDigit() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Enter Mobile Number - WorthUnzip") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Enter Mobile Number",
                style = MaterialTheme.typography.h4,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            OutlinedTextField(
                value = mobileNumber,
                onValueChange = { input ->
                    if (input.length <= 10) mobileNumber = input
                },
                placeholder = { Text("Mobile Number") },
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )

            Button(
                onClick = {
                    if (isValidMobile) {
                        navController.navigate("submission_result")
                    }
                },
                enabled = isValidMobile,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Submit")
            }

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "← Go Back",
                modifier = Modifier.clickable { navController.popBackStack() },
                style = MaterialTheme.typography.body1.copy(fontSize = 18.sp),
                color = MaterialTheme.colors.primary
            )
        }
    }
}

@Composable
fun SubmissionResultScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Submission Result") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Mobile Number Submitted Successfully!",
                style = MaterialTheme.typography.h5,
                textAlign = TextAlign.Center
            )
        }
    }
}
