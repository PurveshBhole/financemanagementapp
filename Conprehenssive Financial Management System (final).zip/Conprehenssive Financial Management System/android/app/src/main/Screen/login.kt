package com.example.worthunzip

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

class LoginActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreen()
        }
    }
}

@Composable
fun LoginScreen() {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val allowedUsers = listOf(
        User("purvesh@gmail.com", "123"),
        User("utkarsha@gmail.com", "123"),
        User("sakshi@gmail.com", "123"),
        User("shravani@gmail.com", "123")
    )

    val navController = rememberNavController()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Login") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Login", style = MaterialTheme.typography.h4)

            Spacer(modifier = Modifier.height(16.dp))

            // Email Input Field
            BasicTextField(
                value = email,
                onValueChange = { email = it },
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next),
                keyboardActions = KeyboardActions.Default,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .border(1.dp, Color.Gray)
                    .padding(16.dp),
                decorationBox = { innerTextField ->
                    if (email.isEmpty()) {
                        Text("Email", color = Color.Gray)
                    }
                    innerTextField()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Password Input Field
            BasicTextField(
                value = password,
                onValueChange = { password = it },
                keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions.Default,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .border(1.dp, Color.Gray)
                    .padding(16.dp),
                decorationBox = { innerTextField ->
                    if (password.isEmpty()) {
                        Text("Password", color = Color.Gray)
                    }
                    innerTextField()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Login Button
            Button(
                onClick = {
                    if (isValidUser(email, password, allowedUsers)) {
                        // Navigate to dashboard on valid login
                        Toast.makeText(it.context, "Login Successful", Toast.LENGTH_SHORT).show()
                        // Redirect to another screen (dashboard activity or composable)
                    } else {
                        // Show error message
                        Toast.makeText(it.context, "Invalid email or password", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Login")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Link to create an account or forgot password
            Row {
                TextButton(onClick = { /* Navigate to Create Account Screen */ }) {
                    Text("Create an Account")
                }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(onClick = { /* Navigate to Forgot Password Screen */ }) {
                    Text("Forgot Password")
                }
            }
        }
    }
}

fun isValidUser(email: String, password: String, allowedUsers: List<User>): Boolean {
    return allowedUsers.any { it.email == email && it.password == password }
}

data class User(val email: String, val password: String)
