import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class RealEstateActivity : AppCompatActivity() {

    private val investmentData = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_real_estate)

        val etPurchasePrice: EditText = findViewById(R.id.etPurchasePrice)
        val etPurchaseDate: EditText = findViewById(R.id.etPurchaseDate)
        val btnUploadDocument: Button = findViewById(R.id.btnUploadDocument)
        val etRmName: EditText = findViewById(R.id.etRmName)
        val etRmContact: EditText = findViewById(R.id.etRmContact)
        val etRmAddress: EditText = findViewById(R.id.etRmAddress)
        val btnAddInvestment: Button = findViewById(R.id.btnAddInvestment)
        val btnDownloadStatement: Button = findViewById(R.id.btnDownloadStatement)
        val investmentList: LinearLayout = findViewById(R.id.investmentList)

        var selectedDocumentUri: Uri? = null

        btnUploadDocument.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, 100)
        }

        btnAddInvestment.setOnClickListener {
            val purchasePrice = etPurchasePrice.text.toString()
            val purchaseDate = etPurchaseDate.text.toString()
            val rmName = etRmName.text.toString()
            val rmContact = etRmContact.text.toString()
            val rmAddress = etRmAddress.text.toString()

            if (selectedDocumentUri == null) {
                Toast.makeText(this, "Please upload a document.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val investment = JSONObject().apply {
                put("purchasePrice", purchasePrice)
                put("purchaseDate", purchaseDate)
                put("documentUri", selectedDocumentUri.toString())
                put("rmName", rmName)
                put("rmContact", rmContact)
                put("rmAddress", rmAddress)
            }

            investmentData.put(investment)
            displayInvestments(investmentList)
            Toast.makeText(this, "Investment added successfully!", Toast.LENGTH_SHORT).show()
        }

        btnDownloadStatement.setOnClickListener {
            if (investmentData.length() == 0) {
                Toast.makeText(this, "No investments to download.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val content = StringBuilder("Real Estate Investments Statement:\n\n")
            for (i in 0 until investmentData.length()) {
                val investment = investmentData.getJSONObject(i)
                content.append("Investment ${i + 1}:\n")
                    .append("Purchase Price: ₹${investment.getString("purchasePrice")}\n")
                    .append("Purchase Date: ${investment.getString("purchaseDate")}\n")
                    .append("Relationship Manager:\n")
                    .append("  Name: ${investment.getString("rmName")}\n")
                    .append("  Contact: ${investment.getString("rmContact")}\n")
                    .append("  Address: ${investment.getString("rmAddress")}\n")
                    .append("-------------------------\n")
            }

            val file = File(filesDir, "RealEstateStatement.txt")
            file.writeText(content.toString())

            val uri = Uri.fromFile(file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
            }
            startActivity(Intent.createChooser(shareIntent, "Share Statement"))
        }
    }

    private fun displayInvestments(investmentList: LinearLayout) {
        investmentList.removeAllViews()
        for (i in 0 until investmentData.length()) {
            val investment = investmentData.getJSONObject(i)

            val itemView = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 16, 16, 16)
            }

            val details = """
                Purchase Price: ₹${investment.getString("purchasePrice")}
                Purchase Date: ${investment.getString("purchaseDate")}
                Relationship Manager:
                  Name: ${investment.getString("rmName")}
                  Contact: ${investment.getString("rmContact")}
                  Address: ${investment.getString("rmAddress")}
            """.trimIndent()

            val textView = TextView(this).apply { text = details }
            itemView.addView(textView)

            investmentList.addView(itemView)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }
}
