import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class GoldInvestmentActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GoldInvestmentApp()
        }
    }
}

@Composable
fun GoldInvestmentApp() {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("goldData", Context.MODE_PRIVATE)

    // State for managing gold investment inputs
    var grams by remember { mutableStateOf(TextFieldValue("")) }
    var pricePerGram by remember { mutableStateOf(TextFieldValue("")) }

    // Retrieve saved data
    var goldData by remember {
        mutableStateOf(
            loadGoldInvestments(sharedPreferences)
        )
    }

    // UI Design
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(enabled = true)
            .background(Color(0xFFF9F9F9))
    ) {
        Text(
            text = "Gold Investment",
            style = MaterialTheme.typography.h5,
            modifier = Modifier.padding(8.dp)
        )

        // Input Form
        BasicTextField(
            value = grams,
            onValueChange = { grams = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .background(Color.White, shape = MaterialTheme.shapes.small)
                .padding(8.dp),
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Number
            ),
            singleLine = true
        )
        BasicTextField(
            value = pricePerGram,
            onValueChange = { pricePerGram = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .background(Color.White, shape = MaterialTheme.shapes.small)
                .padding(8.dp),
            keyboardOptions = KeyboardOptions.Default.copy(
                keyboardType = KeyboardType.Number
            ),
            singleLine = true
        )
        Button(
            onClick = {
                val gramsValue = grams.text.toFloatOrNull()
                val priceValue = pricePerGram.text.toFloatOrNull()
                if (gramsValue != null && priceValue != null && gramsValue > 0 && priceValue > 0) {
                    val newInvestment = GoldInvestment(
                        grams = gramsValue,
                        pricePerGram = priceValue,
                        total = gramsValue * priceValue
                    )
                    goldData = goldData + newInvestment
                    saveGoldInvestments(sharedPreferences, goldData)
                    Toast.makeText(context, "Gold investment added!", Toast.LENGTH_SHORT).show()
                    grams = TextFieldValue("")
                    pricePerGram = TextFieldValue("")
                } else {
                    Toast.makeText(context, "Enter valid values", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.padding(8.dp)
        ) {
            Text(text = "Save Gold Investment")
        }

        // Display Gold Investments
        Text(
            text = "Saved Gold Investments",
            style = MaterialTheme.typography.h6,
            modifier = Modifier.padding(8.dp)
        )
        if (goldData.isEmpty()) {
            Text(text = "No gold investments added yet.", modifier = Modifier.padding(8.dp))
        } else {
            goldData.forEachIndexed { index, investment ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    elevation = 4.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Investment ${index + 1}")
                        Text("Grams: ${investment.grams}g")
                        Text("Price per Gram: ₹${investment.pricePerGram}")
                        Text("Total: ₹${investment.total}")
                        Button(
                            onClick = {
                                goldData = goldData - investment
                                saveGoldInvestments(sharedPreferences, goldData)
                                Toast.makeText(context, "Investment deleted.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Text(text = "Delete")
                        }
                    }
                }
            }
        }
    }
}

data class GoldInvestment(val grams: Float, val pricePerGram: Float, val total: Float)

fun loadGoldInvestments(sharedPreferences: android.content.SharedPreferences): List<GoldInvestment> {
    val json = sharedPreferences.getString("goldData", null) ?: return emptyList()
    val type = object : TypeToken<List<GoldInvestment>>() {}.type
    return Gson().fromJson(json, type)
}

fun saveGoldInvestments(sharedPreferences: android.content.SharedPreferences, data: List<GoldInvestment>) {
    val json = Gson().toJson(data)
    sharedPreferences.edit {
        putString("goldData", json)
    }
}
