import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

data class Bond(
    val bondName: String,
    val issuerName: String,
    val bondAmount: Double,
    val interestRate: Double,
    val yearsInvested: Int,
    val finalValue: Double
)

class BondsInvestmentActivity : AppCompatActivity() {

    private lateinit var bondNameEditText: EditText
    private lateinit var issuerNameEditText: EditText
    private lateinit var bondAmountEditText: EditText
    private lateinit var interestRateEditText: EditText
    private lateinit var yearsInvestedEditText: EditText
    private lateinit var saveBondButton: Button
    private lateinit var bondListLayout: LinearLayout
    private lateinit var noDataTextView: TextView
    private lateinit var downloadBondDetailsButton: Button

    private val sharedPreferences by lazy { getSharedPreferences("BondsData", Context.MODE_PRIVATE) }
    private val gson = Gson()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bonds_investment)

        bondNameEditText = findViewById(R.id.bondNameEditText)
        issuerNameEditText = findViewById(R.id.issuerNameEditText)
        bondAmountEditText = findViewById(R.id.bondAmountEditText)
        interestRateEditText = findViewById(R.id.interestRateEditText)
        yearsInvestedEditText = findViewById(R.id.yearsInvestedEditText)
        saveBondButton = findViewById(R.id.saveBondButton)
        bondListLayout = findViewById(R.id.bondListLayout)
        noDataTextView = findViewById(R.id.noDataTextView)
        downloadBondDetailsButton = findViewById(R.id.downloadBondDetailsButton)

        saveBondButton.setOnClickListener { saveBondInvestment() }
        downloadBondDetailsButton.setOnClickListener { downloadBondDetails() }

        displayBondInvestments()
    }

    private fun saveBondInvestment() {
        val bondName = bondNameEditText.text.toString()
        val issuerName = issuerNameEditText.text.toString()
        val bondAmount = bondAmountEditText.text.toString().toDoubleOrNull()
        val interestRate = interestRateEditText.text.toString().toDoubleOrNull()
        val yearsInvested = yearsInvestedEditText.text.toString().toIntOrNull()

        if (bondAmount == null || interestRate == null || yearsInvested == null) {
            Toast.makeText(this, "Please enter valid numeric values.", Toast.LENGTH_SHORT).show()
            return
        }

        val finalValue = bondAmount * Math.pow(1 + interestRate / 100, yearsInvested)
        val newBond = Bond(bondName, issuerName, bondAmount, interestRate, yearsInvested, finalValue)

        val bondData = loadBonds()
        bondData.add(newBond)
        saveBonds(bondData)

        bondNameEditText.text.clear()
        issuerNameEditText.text.clear()
        bondAmountEditText.text.clear()
        interestRateEditText.text.clear()
        yearsInvestedEditText.text.clear()

        displayBondInvestments()

        Toast.makeText(this, "Bond Investment Saved!", Toast.LENGTH_SHORT).show()
    }

    private fun displayBondInvestments() {
        val bondData = loadBonds()
        bondListLayout.removeAllViews()

        if (bondData.isEmpty()) {
            noDataTextView.visibility = TextView.VISIBLE
            return
        }

        noDataTextView.visibility = TextView.GONE

        bondData.forEachIndexed { index, bond ->
            val bondView = TextView(this).apply {
                text = """
                    Bond ${index + 1}:
                    Name: ${bond.bondName}
                    Issuer: ${bond.issuerName}
                    Amount: ₹${"%.2f".format(bond.bondAmount)}
                    Interest Rate: ${bond.interestRate}%
                    Years: ${bond.yearsInvested}
                    Final Value: ₹${"%.2f".format(bond.finalValue)}
                """.trimIndent()
            }
            bondListLayout.addView(bondView)
        }
    }

    private fun downloadBondDetails() {
        val bondData = loadBonds()
        if (bondData.isEmpty()) {
            Toast.makeText(this, "No data to download.", Toast.LENGTH_SHORT).show()
            return
        }

        val content = bondData.joinToString("\n\n") {
            """
                Bond:
                Name: ${it.bondName}
                Issuer: ${it.issuerName}
                Amount: ₹${"%.2f".format(it.bondAmount)}
                Interest Rate: ${it.interestRate}%
                Years: ${it.yearsInvested}
                Final Value: ₹${"%.2f".format(it.finalValue)}
            """.trimIndent()
        }

        val file = File(filesDir, "BondDetails.txt")
        file.writeText(content)

        Toast.makeText(this, "Details downloaded to ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun loadBonds(): MutableList<Bond> {
        val json = sharedPreferences.getString("bondsData", "[]") ?: "[]"
        val type = object : TypeToken<MutableList<Bond>>() {}.type
        return gson.fromJson(json, type)
    }

    private fun saveBonds(bonds: List<Bond>) {
        val json = gson.toJson(bonds)
        sharedPreferences.edit().putString("bondsData", json).apply()
    }
}
