import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class WelcomeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WelcomeApp()
        }
    }
}

@Composable
fun WelcomeApp() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "welcome") {
        composable("welcome") { WelcomeScreen(navController) }
        composable("create_account") { CreateAccountScreen() }
        composable("login") { LoginScreen() }
        composable("biometric_login") { BiometricLoginScreen() }
    }
}

@Composable
fun WelcomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("WorthUnzip - Welcome") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo), // Replace with your logo resource
                contentDescription = "WorthUnzip Logo",
                modifier = Modifier.size(150.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Welcome to WorthUnzip",
                style = MaterialTheme.typography.h4
            )

            Text(
                text = "Your go-to platform for managing physical and digital assets",
                style = MaterialTheme.typography.body1,
                modifier = Modifier.padding(top = 8.dp, bottom = 24.dp),
                fontSize = 16.sp
            )

            Button(
                onClick = { navController.navigate("create_account") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text("Create an Account")
            }

            Button(
                onClick = { navController.navigate("login") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text("Login")
            }

            Button(
                onClick = { navController.navigate("biometric_login") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Biometric Login")
            }
        }
    }
}

@Composable
fun CreateAccountScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create an Account") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Create Account Screen (Placeholder)")
        }
    }
}

@Composable
fun LoginScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Login") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Login Screen (Placeholder)")
        }
    }
}

@Composable
fun BiometricLoginScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Biometric Login") },
                backgroundColor = MaterialTheme.colors.primary
            )
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Biometric Login Screen (Placeholder)")
        }
    }
}
